from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver import ActionChains
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException
import time
import datetime
import xlrd
import pandas as pd
import os
import pyautogui
import glob
import pandas
import datacompy

def read_input_details():
    
    filename = r"D:\Work\SPARTA\Tableu Comparison\Input_Details.xlsx"
    input_details=pd.read_excel(filename,index_col=0,header=None)
    input_details_trans = input_details.transpose()
    input_details_dict = input_details_trans.to_dict('list')
    return input_details_dict
	
def get_filename(path) :
         import os
         base=os.path.basename(path)
         return os.path.splitext(base)[0]      

def csv_compare(source_filename,target_filename,COMP_RES_PATH):
    start_time = time.time()
    f = open(COMP_RES_PATH+"/"+get_filename(source_filename)+"_comparison_Summary.txt","w")
    Azure_DF = pandas.read_csv(source_filename,error_bad_lines=False)
    Azure_DF.fillna(0,inplace=True)
    # print("\t\tAzure Data is converted to a Dataframe\n\t\tMemory occupied by Azure Dataframe is :"+str(mem_usage(Azure_DF))+".")
    Azure_DF.drop_duplicates(keep='first',inplace=True)
    # for col in Azure_DF.columns:
    #     if not col in eval(str(ws.cell(row=18,column=2).value)):
    #         num_unique_values = len(Azure_DF[col].unique())
    #         num_total_values = len(Azure_DF[col])
    #         if num_unique_values / num_total_values < 0.5:
    #             Azure_DF.loc[:,col] = Azure_DF[col].astype('category')
    #         else:
    #             Azure_DF.loc[:,col] = Azure_DF[col]
    # print("\t\tThe above Azure Dataframe is optimized. \n\t\tMemory occupied by Azure Dataframe after optimization is :"+str(mem_usage(Azure_DF))+".  Time taken for Optimization:"+str((time.time()-start_time)//60)+" minutes and "+str((time.time()-start_time)%60)+" seconds")
    Denodo_DF = pandas.read_csv(target_filename,error_bad_lines=False)
    Denodo_DF.fillna(0,inplace=True)
    # print("\t\tDenodo Data is converted to a Dataframe\n\t\tMemory occupied by Denodo Dataframe is :"+str(mem_usage(Denodo_DF))+".")
    Denodo_DF.drop_duplicates(keep='first',inplace=True)
    # for col in Denodo_DF.columns:
    #     if not col in eval(str(ws.cell(row=18,column=2).value)):
    #         num_unique_values = len(Denodo_DF[col].unique())
    #         num_total_values = len(Denodo_DF[col])
    #         if num_unique_values / num_total_values < 0.5:
    #             Denodo_DF.loc[:,col] = Denodo_DF[col].astype('category')
    #         else:
    #             Denodo_DF.loc[:,col] = Denodo_DF[col]
    # print("\t\tThe above Denodo Dataframe is optimized. \n\t\tMemory occupied by Denodo Dataframe after optimization is :"+str(mem_usage(Denodo_DF))+".  Time taken for Optimization:"+str((time.time()-start_time)//60)+" minutes and "+str((time.time()-start_time)%60)+" seconds")
    print("#################  Comparison is started  #################")
    compare = datacompy.core.Compare(Azure_DF,Denodo_DF,join_columns=Denodo_DF.columns.tolist(),on_index=False)
    #f.write(compare.report().encode("utf-8"))
    f.write(compare.report())
    f.close()
    print("Validation is Completed \nTotaltime taken for this Validation:"+str((time.time()-start_time)//60)+" minutes and "+str((time.time()-start_time)%60)+" seconds")
    print("Open the file named '{}' for detailed summary".format(get_filename(source_filename)+"_comparison_Summary.txt"))

	
def call_compare(source_directory,target_directory,COMP_RES_PATH) :
    import glob 
    import pprint,os
    # source_directory = raw_input("Enter source directory: ")
    # target_directory = raw_input("Enter target directory: ")

    #source_directory = "D:/Work/SPARTA/Tableu Comparison/SOURCE/download"
    #target_directory = "D:/Work/SPARTA/Tableu Comparison/TARGET/download"
    print("source_directory inside call compare:"+source_directory)
    print("target_directory inside call compare:"+target_directory)
    print("comp result inside call compare:"+COMP_RES_PATH)

    def get_filename(path) :
         import os
         base=os.path.basename(path)
         return os.path.splitext(base)[0]      

    def get_latest_source_file(file_name) :
        candidate_source_files = [] 
        for source_files in glob.glob(source_directory+"/*"+file_name+"*") :
            candidate_source_files.append((source_files,os.path.getmtime(source_files)))
        return max(candidate_source_files, key= lambda x : x[1] )[0]


    target_filelist = glob.glob(target_directory+"/*")
    for target_filename in target_filelist :
        source_filename = get_latest_source_file(get_filename(target_filename))
        print(source_filename)
        print(target_filename)
        print()
        csv_compare(source_filename,target_filename,COMP_RES_PATH)


def login_download(URL,User_Id,PWD,Metrics,TGT_Path):
    
    
    File_temp=TGT_Path+'\\temp'
    if not os.path.isdir(File_temp):
        os.mkdir(File_temp)
        for file in os.listdir(File_temp):
            print(file)
            os.remove(File_temp+"\\"+file)
    File_Destination=TGT_Path+'\\download'
    if not os.path.isdir(File_Destination):
        os.mkdir(File_Destination)
        for file in os.listdir(File_Destination):
            print(file)
            os.remove(File_Destination+"\\"+file)
    ####  changing download path
    chrome_options = Options()
    chrome_options.add_argument('--disable-infobars')
    chrome_options.add_experimental_option("prefs",{"download.default_directory":File_temp})
    driver = webdriver.Chrome(options=chrome_options)
    driver.maximize_window() 
    
    # Logging in dashboard
    driver.get(URL)
    time.sleep(10)
    Logid = driver.find_element_by_xpath('//*[@id="ng-app"]/div/div/div/div[2]/span/form/div[1]/div[1]/div/div/input')
    time.sleep(3)
    Logid.send_keys(User_Id)
    time.sleep(3)
    Logpswd = driver.find_element_by_xpath('//*[@id="ng-app"]/div/div/div/div[2]/span/form/div[1]/div[2]/div/div/input')
    Logpswd.send_keys(PWD)
    driver.find_element_by_xpath('//*[@id="ng-app"]/div/div/div/div[2]/span/form/button').click()
    time.sleep(10)

    metricsname_list = list(Metrics.split(','))
    print(metricsname_list)
    File_list=list(File_Name.split(','))
    print(File_list)
    curr_win=driver.current_window_handle
    ##curr_win=driver.getTitle()
    print(curr_win)
    print(driver.title)
    i=0  
    for l in metricsname_list:
        ##creating new folder
 
        Filename=File_list[i]
        print(Filename)
               
        print(l)
        iframe = driver.find_elements_by_tag_name('iframe')[0]
        driver.switch_to.frame(iframe)
        driver.implicitly_wait(30)
        try:
            ##print(driver.find_element_by_xpath(l))
            driver.find_element_by_xpath(l).click()
            #metrics.click()
            #metrics=driver.find_element_by_xpath('//*[@id="view11485452951787285008_18196574034706757250"]/div[1]/div[2]/canvas[2]').click()
            time.sleep(10)
            print ("Data got selected")
        except Exception as e:
            print(e)
            print("Data not selected")
        window_before = driver.current_window_handle
        driver.find_element_by_xpath("//div[@id='toolbar-container']//div[@class='tabToolbarButton tab-widget download']//span[text()='Download']").click()
        time.sleep(4)
        #Selecting the file format as image
        driver.find_element_by_xpath("//div[@data-tb-test-id='DownloadDialog-Dialog-Body']//div[@class='tab-downloadDialog']//div[text()='Data']").click()
        time.sleep(5)
        #driver.switch_to.window("View Data")
        window_after = driver.window_handles[1]
        #time.sleep(3)
        driver.switch_to.window(window_after)
        driver.find_element_by_xpath('//*[@id="tab-view-full-data"]').click()
        #print ("Sucess")
        time.sleep(2)
        driver.find_element_by_xpath('//*[@id="tabContent-panel-underlying"]/div[2]/div/label/div[1]/input').click()
        #window_after = driver.window_handles[1]
        time.sleep(3)
        
        #time.sleep(3)
        driver.find_element_by_xpath('//*[@id="tabContent-panel-underlying"]/div[1]/div[2]/a').click()
        driver.close()
        #driver.switch_to_default_content
        driver.switch_to.window(window_before)
        time.sleep(10)
        curr_window=driver.current_window_handle
        print('**************second_click********')
        print(curr_window)
        print(driver.title)
        #print(l)
        try:
            #driver.refresh()
            pyautogui.press("F5")
            time.sleep(10)
            print("Refreshed")
        except:
            print("Not Refreshed")
        i=+1
        print(i)
        waitflag=0
        while waitflag == 0:
            currentFile = glob.glob(File_temp+"\\*.csv")
            if not currentFile:
                print("File is not downloaded. Waiting for file to download")
                time.sleep(10)
            else:
                waitflag=1
        filenm = Filename+".csv"
        currentloc = ''.join(currentFile)
        os.chdir(File_Destination)
        print(os.getcwd())
        print(currentloc)
        try:
            os.rename(currentloc,filenm)
        except FileExistsError:
            now=datetime.datetime.now().strftime("%y%m%d%H%M%S")
            os.rename(currentloc,Filename+'_'+str(now)+'.csv')
        ##rename='2013.xlsx'
        ##try:
            ##os.rename(TGT_Path,rename)
            ##print("Rename done")
        ##except:
            ##print("unable to rename")
    return driver



input_details_dict=read_input_details()
URL = ''.join([str(l) for l in input_details_dict['Dashboard URL']])
User_Id = ''.join([str(l) for l in input_details_dict['User ID']])
PWD = ''.join([str(l) for l in input_details_dict['PWD']])
no_of_metrics = ''.join([str(l) for l in input_details_dict['No. of metrics']])
Metrics = ''.join([str(l) for l in input_details_dict['Metrics']])
TGT_Path = ''.join([str(l) for l in input_details_dict['TGT Path']])
File_Name = ''.join([str(l) for l in input_details_dict['File Name']])
SRC_path= ''.join([str(l) for l in input_details_dict['SRC Path']])
COMP_RES_PATH= ''.join([str(l) for l in input_details_dict['COMP Result path']])

print(URL)
print(User_Id)
print(PWD)
print(no_of_metrics)
print(Metrics)
print(TGT_Path)
print(File_Name)
print("source path ="+SRC_path)
print("Comparison result path ="+COMP_RES_PATH)

login_download(URL,User_Id,PWD,Metrics,TGT_Path)
#driver.close()

call_compare(SRC_path,TGT_Path+"/download",COMP_RES_PATH)
