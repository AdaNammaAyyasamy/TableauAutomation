import pandas as pd
 
A = pd.read_csv('1.csv', index_col=0)
B = pd.read_csv('2.csv', index_col=0)
 
C = pd.merge(left=A,right=B, how='outer', left_index=True, right_index=True, suffixes=['_a', '_b'])
 
not_in_a = C.drop( A.index )
not_in_b = C.drop( B.index )
 
not_in_a.to_csv('not_in_a.csv')
not_in_b.to_csv('not_in_b.csv')